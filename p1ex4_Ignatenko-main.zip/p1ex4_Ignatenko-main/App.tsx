import React, {useState} from 'react';
import {StyleSheet, Button, Text, View} from 'react-native';

type CatProps = {
  name: string;
};

const Cat = (props: CatProps) => {
  const [isHungry, setIsHungry] = useState(true);

  return (
    <View>
      <Text>
        Меня зовут {props.name}, И я {isHungry ? 'голодный' : 'сытый'}!
      </Text>
      <Button
        onPress={() => {
          setIsHungry(false);
        }}
        disabled={!isHungry}
        title={isHungry ? 'Дай мне мою еду пожалуйста!' : 'Спасибо!'}
      />
    </View>
  );
};

const Cafe = () => {
  return (
    <View>
      <Cat name="Гулин" />
      <Cat name="Илья" />
      <Cat name="Мотоблок" />
    </View>
  );
};

export default Cafe;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
